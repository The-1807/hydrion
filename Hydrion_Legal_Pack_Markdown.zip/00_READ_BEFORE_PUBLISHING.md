# READ BEFORE PUBLISHING

## Status

This package is a tailored working draft for Hydrion. It is not a substitute for advice from a lawyer licensed in the markets where Hydrion will operate.

## Draft assumptions

This draft assumes the following product and operating model:

- Hydrion is operated from Ontario, Canada.
- The current MVP is local-first. Hydration logs, reminders, goals, settings, streaks, achievements, analytics summaries, challenges, and local coach outputs remain on the user's device unless the user deliberately enables a future account, cloud sync, export, support, or integration feature.
- Hydrion is a general wellness and hydration tracking product, not a medical device, diagnostic service, emergency service, or substitute for professional care.
- Hydrion does not sell personal information, use health or wellness information for targeted advertising, or provide personal information to data brokers.
- External AI providers are disabled in the current MVP. The local coach uses on-device or locally implemented fallback logic. Any future external AI processing requires an updated notice and a separate, clear user choice before data is transmitted.
- Apple Health, HealthKit, Google Health Connect, wearable, cloud sync, analytics, crash reporting, social, subscription, and advertising features may not yet be active. Where a feature is not available in a user's build, the related collection or sharing does not occur.
- Account creation may be introduced later. The account and deletion clauses are drafted now so the product can be prepared for that release.
- The minimum account age is 13, subject to stricter local law and parent or guardian involvement where required.

## Details that must be completed before publication

Replace every bracketed field and verify every operational promise:

- [OPERATOR LEGAL NAME]
- [BUSINESS OR MAILING ADDRESS]
- [PRIVACY EMAIL]
- [SUPPORT EMAIL]
- [WEBSITE URL]
- [ACCOUNT DELETION URL]
- [EFFECTIVE DATE]
- [LIST OF ACTIVE SERVICE PROVIDERS]
- [FINAL DATA RETENTION PERIODS]
- [FINAL ACCOUNT AGE]

## Product implementation commitments created by these documents

Before publishing these documents, Hydrion should be able to do what the documents promise, including:

1. Show the Terms of Use and Privacy Policy during account creation.
2. Keep marketing consent separate and optional.
3. Ask for notification, health platform, wearable, location, Bluetooth, camera, or photo permissions only when the related feature is used.
4. Provide Settings > Legal, Privacy and Safety.
5. Provide Settings > Account > Delete Account when accounts are enabled.
6. Provide a public web route where an account deletion request can be submitted without reinstalling the app.
7. Record the policy version and acceptance timestamp for account users.
8. Provide data access, correction, export, and deletion workflows.
9. Maintain a current processor and SDK inventory.
10. Match the Apple App Privacy and Google Play Data Safety disclosures to the app's actual behaviour.
11. Keep health and wellness data out of targeted advertising and data brokerage.
12. Maintain breach detection, response, recordkeeping, notification, and escalation procedures.
13. Update these documents before adding cloud sync, external AI, social features, subscriptions, research, or new sensitive permissions.

## Recommended signup wording

By creating an account, you agree to the Hydrion Terms of Use and acknowledge the Hydrion Privacy Policy. Hydrion is a general wellness tool and does not provide medical advice.

Use separate unchecked controls for optional marketing, research, analytics, or personalization that is not necessary to deliver the requested service.
