# Hydrion Health and Wellness Disclaimer

**Effective date:** [EFFECTIVE DATE]  
**Last updated:** July 6, 2026

## 1. General wellness purpose

Hydrion is a general wellness and hydration tracking tool. It helps users record fluid intake, configure reminders, review trends, set personal goals, track streaks and achievements, and receive general informational prompts.

Hydrion does not provide medical advice, diagnosis, treatment, prevention, monitoring, emergency assistance, or a professional standard of care. Hydrion is not a doctor, nurse, dietitian, pharmacist, emergency service, or substitute for a qualified healthcare professional.

## 2. Hydration needs are individual

Hydration needs can vary based on age, body size, pregnancy, breastfeeding, climate, altitude, diet, activity, illness, medications, disability, kidney function, heart function, endocrine conditions, fluid restrictions, and many other factors.

A goal, score, reminder, prediction, streak, or recommendation shown by Hydrion is a general estimate based on available inputs and product logic. It may be too high, too low, incomplete, or inappropriate for you.

Do not force yourself to meet an app goal. More fluid is not always better. Excessive fluid intake can be harmful, and some people must limit fluids under professional guidance.

## 3. Follow professional instructions

If a qualified healthcare professional has provided fluid, electrolyte, medication, dietary, fasting, or activity instructions, follow those instructions rather than Hydrion.

Speak with a qualified professional before relying on a hydration goal if you:

- have kidney, heart, liver, endocrine, blood pressure, electrolyte, swallowing, or fluid-balance concerns;
- have been advised to restrict or closely manage fluid intake;
- are pregnant or breastfeeding;
- are taking medication that affects fluid balance, urination, sodium, blood pressure, or alertness;
- are experiencing vomiting, diarrhea, fever, heat illness, significant sweating, or another acute condition;
- are preparing for or recovering from surgery or a medical procedure;
- are supporting a child, older adult, or person who cannot reliably communicate symptoms; or
- are uncertain whether a hydration target is safe for you.

This list is not complete.

## 4. Symptoms and emergencies

Do not use Hydrion to assess whether a symptom is serious. Stop using the app and seek appropriate professional help if you are concerned about your health.

Call local emergency services or seek urgent medical care for severe or rapidly worsening symptoms, including confusion, fainting, seizure, severe weakness, breathing difficulty, chest pain, inability to keep fluids down, signs of severe heat illness, or another situation that may be an emergency.

Hydrion cannot contact emergency services, monitor you continuously, or guarantee that a reminder or alert will be delivered.

## 5. Reminders are not safety alerts

Hydrion reminders are convenience notifications. They may be delayed, silenced, duplicated, or missed because of operating system settings, battery restrictions, device shutdown, app suspension, time zone changes, network conditions, software defects, or user configuration.

Do not use Hydrion as a medication alarm, clinical monitoring system, workplace safety control, or emergency warning system.

## 6. Beverage and nutrition information

Hydrion may allow different beverage types or estimates of water contribution. These values may be generalized and may not reflect serving size, alcohol, caffeine, sugar, sodium, ingredients, medical restrictions, or individual response.

Hydrion does not certify the safety, quality, ingredients, or nutritional value of a beverage. Review product labels and obtain professional guidance where needed.

## 7. Wearables, health platforms, and sensors

Information from Apple Health, HealthKit, Health Connect, phones, watches, fitness trackers, motion sensors, weather sources, or other integrations may be incomplete, delayed, duplicated, estimated, or incorrect.

A connected device or integration does not turn Hydrion into a medical monitoring service. Check important information independently.

## 8. AI and automated outputs

Hydrion may provide rule-based, predictive, or AI-assisted text. Automated outputs can be inaccurate, generalized, or fabricated and may not account for your medical history or current condition.

Do not treat automated output as a diagnosis, prescription, treatment plan, clearance to exercise, instruction to change medication, or reason to delay professional care.

The current local-first MVP uses local fallback logic rather than sending hydration information to an external AI provider by default.

## 9. User responsibility

You are responsible for deciding whether and how to use Hydrion, entering information accurately, reviewing device settings, applying common sense, and obtaining professional advice where appropriate.

Parents, guardians, caregivers, coaches, and employers should not use Hydrion as the sole method of supervising another person's fluid intake or safety.

## 10. Acknowledgement

By using Hydrion, you acknowledge that:

- Hydrion is a general wellness tool;
- Hydrion does not replace a healthcare professional;
- goals, reminders, scores, and automated outputs may be inaccurate or unsuitable;
- you will follow professional instructions that apply to you; and
- you will seek appropriate medical or emergency help when needed.

Questions about this disclaimer may be sent to [SUPPORT EMAIL].
