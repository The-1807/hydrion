# Internal Drafting References

This section is for the publisher and legal reviewer. It is not intended to appear inside the user-facing policy pages.

The draft was structured around the following official guidance and platform requirements current as of July 6, 2026:

1. Office of the Privacy Commissioner of Canada, Guidelines for obtaining meaningful consent: https://www.priv.gc.ca/en/privacy-topics/business-privacy/collecting-personal-information/consent/gl_omc_201805/
2. Office of the Privacy Commissioner of Canada, Good privacy practices for developing mobile apps: https://www.priv.gc.ca/en/privacy-topics/technology/mobile-and-digital-devices/mobile-apps/gd_app_201210/
3. Office of the Privacy Commissioner of Canada, Mandatory reporting of breaches of security safeguards: https://www.priv.gc.ca/en/privacy-topics/business-privacy/breaches-and-safeguards/privacy-breaches-at-your-business/gd_pb_201810/
4. Apple App Review Guidelines: https://developer.apple.com/app-store/review/guidelines/
5. Apple, Offering account deletion in your app: https://developer.apple.com/support/offering-account-deletion-in-your-app/
6. Apple, Health and fitness apps: https://developer.apple.com/health-fitness/
7. Apple, Protecting user privacy with HealthKit: https://developer.apple.com/documentation/healthkit/protecting-user-privacy
8. Google Play, Understanding app account deletion requirements: https://support.google.com/googleplay/android-developer/answer/13327111
9. Google Play, Data Safety section: https://support.google.com/googleplay/android-developer/answer/10787469
10. Google Play, Health Content and Services: https://support.google.com/googleplay/android-developer/answer/16679511
11. Google Play, Android Health Permissions guidance: https://support.google.com/googleplay/android-developer/answer/12991134
12. U.S. Federal Trade Commission, Health Breach Notification Rule: https://www.ftc.gov/legal-library/browse/rules/health-breach-notification-rule

The final documents must be reviewed against the actual data map, SDK inventory, authentication design, hosting regions, retention configuration, account deletion implementation, app store declarations, and target jurisdictions before publication.
