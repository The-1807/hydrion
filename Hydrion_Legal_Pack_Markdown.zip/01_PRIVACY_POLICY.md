# Hydrion Privacy Policy

**Effective date:** [EFFECTIVE DATE]  
**Last updated:** July 6, 2026

## 1. Introduction

Hydrion is a hydration tracking and general wellness application. This Privacy Policy explains how [OPERATOR LEGAL NAME], operating Hydrion from Ontario, Canada, collects, uses, discloses, protects, retains, and deletes personal information when you use the Hydrion mobile application, web experiences, support channels, testing programs, and related services.

In this policy, "Hydrion," "we," "us," and "our" refer to [OPERATOR LEGAL NAME]. "You" and "user" refer to the individual using Hydrion.

Hydrion is designed as a local-first product. In builds where account or cloud features are not enabled, most hydration and wellness information remains on your device. Where a feature described below is not available in your version, the related collection or disclosure does not occur.

## 2. Privacy summary

The most important points are:

- Hydrion collects only information reasonably needed to provide the features you choose to use.
- Local hydration logs and settings remain on your device unless you enable a feature that sends them elsewhere, such as future cloud sync, account backup, support submission, export, Apple Health, Health Connect, or a wearable integration.
- Hydrion does not sell personal information.
- Hydrion does not use health or wellness information for targeted advertising or provide it to data brokers.
- External AI services are not used in the current local-first MVP. If a future feature sends information to an external AI provider, Hydrion will provide a clear notice before transmission and will request any consent required by law.
- You can manage permissions in your device settings and, when accounts are enabled, request access, correction, export, or deletion of account information.
- Hydrion is a general wellness product. It is not a medical provider or emergency service.

## 3. Scope

This policy applies to:

- the Hydrion application on supported mobile, web, and desktop platforms;
- Hydrion account registration and authentication, when enabled;
- optional cloud backup and synchronization, when enabled;
- reminders, hydration goals, streaks, achievements, analytics summaries, challenges, and local coaching features;
- optional Apple Health, HealthKit, Google Health Connect, smartwatch, fitness tracker, or wearable integrations;
- Hydrion support, feedback, issue reporting, alpha testing, and beta testing channels; and
- Hydrion websites or account deletion pages that link to this policy.

This policy does not govern third-party services that have their own privacy policies, including app stores, device manufacturers, operating systems, identity providers, or external websites.

## 4. Information Hydrion may process

### 4.1 Information stored locally on your device

Depending on the features you use, Hydrion may store the following information locally:

- hydration entries, including amount, beverage type, date, and time;
- daily goals, preferred units, reminder schedules, notification preferences, and app settings;
- streaks, achievements, challenge progress, hydration scores, analytics summaries, and eco-impact estimates;
- optional profile details used to personalize general wellness estimates, such as age range, body weight, activity level, climate preference, wake and sleep schedule, and selected goals;
- language, theme, accessibility, and display preferences;
- local coach prompts, templates, responses, and feature capability settings; and
- app state required to restore your experience.

Local information may be included in device backups controlled by Apple, Google, your device manufacturer, or another backup provider. Those backups are governed by the provider's terms and privacy policy.

Deleting the app, clearing app storage, resetting the device, or losing the device may remove local information. Hydrion cannot recover local-only information that was never transmitted to Hydrion.

### 4.2 Account and identity information

When account creation is enabled and you choose to register, Hydrion may collect:

- name or display name;
- email address;
- username;
- authentication identifier;
- encrypted or hashed password credentials, when Hydrion manages passwords directly;
- sign-in provider information, when you use Apple, Google, or another supported identity provider;
- account creation date, verification status, consent records, and policy acceptance version; and
- account security information, including login events, failed login attempts, and recovery requests.

Hydrion should never request your account password through support messages.

### 4.3 Cloud synchronization and account backup information

If cloud synchronization or backup is enabled and you choose to use it, Hydrion may receive the hydration, goal, reminder, profile, achievement, challenge, analytics, and preference information selected for synchronization.

Hydrion will identify which categories are synchronized before you enable the feature. You may be able to disable sync, but disabling sync does not automatically delete information already stored in your account. Account deletion or a separate deletion request may be required.

### 4.4 Health platform and wearable information

If Hydrion supports Apple Health, HealthKit, Google Health Connect, smartwatches, fitness trackers, or another health or wearable platform, Hydrion may request access to specific categories that are necessary for the feature you activate. These may include water intake, activity, workouts, step counts, body measurements, or other supported data types.

Hydrion will:

- request only the categories reasonably required for the selected feature;
- display the operating system permission prompt and an explanation of the purpose;
- respect your permission choices;
- avoid using health platform data for advertising, marketing profiling, or data brokerage;
- avoid accessing a data category when permission has not been granted; and
- allow you to disconnect the integration through Hydrion or the relevant platform settings where technically available.

The operating system may not tell Hydrion whether you denied read access to a specific HealthKit category. Hydrion will not attempt to bypass platform privacy controls.

### 4.5 Device, app, and diagnostic information

Depending on the build and enabled services, Hydrion may process:

- device type, operating system version, app version, language, and time zone;
- installation identifier or account-linked device identifier;
- feature usage events needed to operate, secure, or improve the service;
- crash reports, error messages, performance information, and diagnostic logs;
- notification delivery tokens and delivery status;
- approximate network information, such as IP address, when you connect to an online Hydrion service; and
- security events used to detect abuse, fraud, account compromise, or unauthorized access.

The current local-first MVP may not transmit analytics or crash reports to Hydrion. Before enabling any diagnostic provider, Hydrion will update its service provider inventory, store disclosures, and this policy as necessary.

### 4.6 Support, feedback, and community information

When you contact Hydrion, submit a bug report, user story, feature request, review, or other feedback, Hydrion may receive:

- your name, email address, username, or GitHub account details;
- the message and attachments you submit;
- screenshots, logs, device details, or reproduction steps you choose to provide;
- repository, issue, discussion, or project activity that is public on the platform you use; and
- correspondence and resolution records.

Do not include medical records, government identifiers, financial account details, passwords, or other unnecessary sensitive information in a support or public issue report.

### 4.7 Purchase and subscription information

If Hydrion later offers paid features, the applicable app store or payment provider will process payment credentials. Hydrion may receive transaction identifiers, subscription status, product purchased, renewal status, country, currency, and refund status. Hydrion generally does not receive full payment card numbers from app stores.

## 5. How Hydrion obtains information

Hydrion may obtain information:

- directly from you;
- automatically from the app, device, browser, or Hydrion service when necessary for the requested feature;
- from an identity provider you select;
- from Apple Health, HealthKit, Health Connect, a wearable, or another integration you authorize;
- from app stores and payment providers;
- from support, issue tracking, testing, or community platforms; and
- from service providers acting on Hydrion's instructions.

## 6. Why Hydrion uses information

Hydrion may use personal information to:

1. create, authenticate, secure, and maintain an account;
2. store and display hydration records, goals, reminders, streaks, achievements, analytics summaries, challenges, and preferences;
3. provide local or account-based personalization requested by the user;
4. operate optional cloud synchronization, backup, export, integration, or recovery features;
5. deliver reminders, service notices, security alerts, and requested communications;
6. diagnose crashes, correct defects, test compatibility, and improve reliability;
7. detect misuse, protect accounts, enforce the Terms of Use, and investigate security events;
8. answer support requests and manage feedback;
9. administer alpha and beta testing;
10. comply with legal obligations, lawful requests, and valid dispute processes;
11. protect the rights, safety, property, and integrity of users, Hydrion, and others; and
12. create aggregated or de-identified statistics that are not reasonably capable of identifying an individual.

Hydrion will not use personal information for a materially different purpose without providing notice and obtaining consent where required.

## 7. Consent and user choice

Hydrion seeks meaningful consent by presenting important information in clear language and by separating required processing from optional features.

Some processing is necessary to provide a service you request. Other processing is optional, such as marketing, external integrations, research participation, non-essential analytics, or future external AI personalization. Optional choices should not be preselected.

You may withdraw consent for optional processing through the app, device settings, the relevant third-party platform, or by contacting Hydrion. Withdrawal does not invalidate processing that occurred lawfully before withdrawal and may prevent the related feature from working.

Permission to access a device capability is not treated as permission to use information for an unrelated purpose.

## 8. Artificial intelligence and automated personalization

The current local-first Hydrion MVP uses local fallback logic and prompt templates. It does not send hydration information to an external AI provider by default.

If Hydrion later introduces an external AI feature, Hydrion will identify:

- the information sent;
- the provider receiving it;
- the purpose of the processing;
- whether the information is retained or used to improve provider models;
- available controls; and
- any consequences of declining.

AI-generated or automated outputs are estimates and may be incomplete, inaccurate, or unsuitable for an individual's health circumstances. They must not be treated as medical advice or emergency guidance.

## 9. Notifications and device permissions

Hydrion may request notifications to deliver reminders and service alerts. Notification permission is optional. You can disable notifications through Hydrion settings or device settings.

Hydrion may request other permissions only when needed for a feature, such as health data, Bluetooth, motion, camera, photos, files, or location. The permission prompt and nearby explanation should describe the immediate purpose. Hydrion will not attempt to manipulate you into granting unnecessary access.

## 10. When Hydrion discloses information

Hydrion may disclose personal information in the following limited circumstances.

### 10.1 Service providers

Hydrion may use providers for hosting, authentication, email delivery, notifications, customer support, analytics, crash reporting, security, payments, and other operational functions. Providers may process information only for the contracted service and must be subject to appropriate confidentiality, security, and data protection obligations.

The active provider list will be maintained at [WEBSITE URL]/privacy/providers or in this policy: [LIST OF ACTIVE SERVICE PROVIDERS].

### 10.2 Integrations chosen by the user

When you connect Apple Health, HealthKit, Health Connect, a wearable, an export destination, or another service, information may be exchanged according to your selections and the provider's rules.

### 10.3 Legal and safety reasons

Hydrion may preserve or disclose information when reasonably necessary to comply with applicable law, a valid court order, a lawful government request, or a legal process; investigate fraud or security incidents; enforce agreements; or protect the rights, safety, and property of Hydrion, users, or others.

Hydrion will review requests for validity and scope where legally permitted.

### 10.4 Business transactions

If Hydrion is involved in a merger, financing, reorganization, sale, acquisition, insolvency, or transfer of all or part of the service, information may be disclosed under confidentiality and legal safeguards. Users will receive notice when required and when control of personal information materially changes.

### 10.5 With your direction or consent

Hydrion may disclose information when you direct it to do so or give valid consent.

## 11. No sale and no targeted advertising using health information

Hydrion does not sell personal information. Hydrion does not disclose health or wellness information to data brokers. Hydrion does not use information from HealthKit, Apple Health, Health Connect, hydration logs, body measurements, or wellness profiles for targeted advertising or cross-service behavioural advertising.

If Hydrion ever introduces advertising, this policy and the app's consent controls will be updated before launch, and health or wellness information will remain excluded from advertising profiles.

## 12. Data retention

Hydrion retains information only for as long as reasonably necessary for the purposes described in this policy, legal obligations, security, dispute resolution, and enforcement.

The intended baseline schedule is:

- local-only data: until you delete it, clear app storage, delete the app, reset the device, or a local retention control removes it;
- active account information and synchronized content: while the account remains active and as needed to provide the service;
- deleted account production data: deletion or irreversible de-identification within 30 days after verification of the request, except where retention is legally required;
- encrypted backup copies: removed through normal backup rotation within 90 days and not restored for ordinary product use after deletion;
- security and authentication logs: up to 12 months unless a longer period is required for an active investigation or legal obligation;
- support and feedback correspondence: up to 24 months after closure, unless a shorter request can be honoured or a longer period is required for a dispute; and
- transaction records: for the period required by tax, accounting, fraud prevention, and consumer protection law.

Before publication, Hydrion must verify that its actual systems implement these periods. If a different schedule is implemented, this section must be updated.

Aggregated or de-identified information that is no longer reasonably capable of identifying you may be retained for legitimate product, security, and research purposes.

## 13. Security safeguards

Hydrion uses administrative, technical, and organizational safeguards appropriate to the sensitivity of the information and the state of the service. Safeguards may include:

- encryption in transit for online services;
- encryption or secure platform storage for credentials and sensitive tokens;
- hashed passwords using an appropriate password hashing method when passwords are managed by Hydrion;
- role-based access and least-privilege controls;
- secure development, dependency review, testing, and vulnerability remediation;
- logging, monitoring, backup, and recovery controls;
- service provider review and contractual protections; and
- incident response and breach recordkeeping procedures.

No system is perfectly secure. Users are responsible for maintaining device security, using a strong unique password, protecting recovery channels, installing updates, and reporting suspected unauthorized access.

## 14. Privacy incidents and breach notification

Hydrion will investigate suspected loss, unauthorized access, use, or disclosure of personal information. Hydrion will take reasonable containment and remediation steps, maintain required records, and notify regulators, affected individuals, or relevant organizations when required by applicable law.

## 15. International processing

Hydrion may use service providers located outside your province, territory, or country. Information processed in another jurisdiction may be subject to the laws and lawful access processes of that jurisdiction.

Hydrion will use contractual, technical, and organizational measures appropriate to the information and the transfer. Contact [PRIVACY EMAIL] to request information about applicable service locations and safeguards.

## 16. Your privacy rights

Depending on your location and subject to legal exceptions, you may have the right to:

- know whether Hydrion holds personal information about you;
- request access to personal information;
- request correction of inaccurate or incomplete information;
- request a portable copy of account information;
- request deletion;
- withdraw consent for optional processing;
- object to or restrict certain processing;
- disconnect integrations and manage permissions;
- complain to Hydrion or an applicable privacy regulator; and
- receive information about significant automated processing where required.

Hydrion may need to verify identity before completing a request. Verification information will be limited to what is reasonably necessary. Hydrion may refuse or limit a request where permitted by law, including where disclosure would reveal another person's information, compromise security, conflict with legal retention duties, or be manifestly unfounded or excessive. Hydrion will explain a refusal where required.

Submit requests to [PRIVACY EMAIL].

## 17. Account deletion

When accounts are enabled, Hydrion will provide an in-app account deletion path at Settings > Account > Delete Account and a public request path at [ACCOUNT DELETION URL].

Account deletion will:

- disable access to the account;
- delete or de-identify account information and synchronized user content, subject to legal exceptions;
- explain any information that must be retained and the reason;
- not automatically remove information retained independently by an app store, identity provider, health platform, wearable provider, or another service; and
- not necessarily delete local data from every device until the app data is cleared or the user follows the local deletion steps.

Hydrion may require reauthentication or another proportionate verification step to protect against unauthorized deletion. Hydrion will not require a user to contact support as the only in-app deletion method where store rules require in-app initiation.

## 18. Children and younger users

Hydrion is not directed to children under 13 and does not knowingly permit account creation by children under 13. A higher minimum age may apply in some locations.

Users who have not reached the age of majority should use Hydrion with parent or guardian awareness and should not rely on Hydrion for medical decisions. If Hydrion learns that it collected a child's personal information contrary to applicable law, it will take reasonable steps to delete it.

A parent or guardian may contact [PRIVACY EMAIL] with a verified request concerning a child's information.

## 19. Third-party links and services

Hydrion may link to GitHub, app stores, support systems, health platforms, wearable services, or other third parties. Hydrion is not responsible for the independent privacy practices of those services. Review their policies before providing information.

## 20. Changes to this policy

Hydrion may update this policy to reflect product changes, law, security practices, or service providers. The updated policy will show a new revision date. Hydrion will provide additional notice, and request consent where required, before a material change takes effect.

Continued use after a non-material update takes effect indicates acknowledgement of the updated policy. Material changes will not be applied retroactively in a manner that requires consent without obtaining that consent.

## 21. Contact Hydrion

**Privacy contact:** [PRIVACY EMAIL]  
**Support contact:** [SUPPORT EMAIL]  
**Operator:** [OPERATOR LEGAL NAME]  
**Address:** [BUSINESS OR MAILING ADDRESS]  
**Website:** [WEBSITE URL]

You may also contact the privacy regulator responsible for your jurisdiction. Canadian users can obtain information from the Office of the Privacy Commissioner of Canada or the applicable provincial privacy authority.
