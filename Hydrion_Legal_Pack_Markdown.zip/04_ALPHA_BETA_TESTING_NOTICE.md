# Hydrion Alpha and Beta Testing Notice

**Testing notice version:** 1.0 Draft  
**Last updated:** July 6, 2026

## 1. Pre-release status

The Hydrion build you are using may be identified as an MVP, alpha, beta, preview, test, development, or experimental release. It is provided to evaluate product direction, compatibility, usability, accessibility, reliability, safety, and feature behaviour before a stable public release.

A testing build is not a final product.

## 2. What testers should expect

During alpha and beta testing, Hydrion may:

- crash, freeze, display incorrectly, or perform slowly;
- contain incomplete, disabled, experimental, or placeholder functionality;
- produce incorrect hydration totals, scores, streaks, achievements, analytics, reminders, challenge results, coach outputs, translations, or accessibility behaviour;
- behave differently across Android, iOS, web, desktop, devices, operating system versions, screen sizes, time zones, and locales;
- change data structures, permissions, navigation, design, or functionality between builds;
- reset, migrate, corrupt, or permanently lose test data;
- require reinstallation, account recreation, cache clearing, or manual migration;
- be unavailable without notice; and
- be discontinued or replaced.

Do not use an alpha or beta build for safety-critical, medical, legal, financial, employment, or recordkeeping purposes.

## 3. Test data and backups

Assume that test data may be lost.

The current local-first MVP may store hydration logs and settings only on the device. Hydrion cannot recover information that was never transmitted. Keep independent records of anything important and do not enter information that you cannot afford to lose.

A test update may intentionally reset local storage to validate migrations or correct defects. Hydrion will try to announce planned destructive testing when practical, but advance notice is not guaranteed.

## 4. Health and safety limitation

Hydrion remains a general wellness product during testing. Test outputs are especially likely to be incomplete or inaccurate.

Do not use a test build for diagnosis, treatment, emergency decisions, fluid restriction management, clinical monitoring, medication timing, or supervision of another person's safety. Follow the Hydrion Health and Wellness Disclaimer and professional instructions.

## 5. Privacy during testing

Hydrion will handle tester information according to the Privacy Policy. A specific test may request optional diagnostics, crash reports, screenshots, screen recordings, or device logs. Hydrion should explain what is requested and why.

Before submitting a report:

- remove passwords, authentication codes, financial information, government identifiers, and unrelated personal information;
- avoid including private medical information unless it is necessary and Hydrion has provided a secure submission method;
- blur or remove another person's information; and
- remember that public GitHub issues and discussions can be viewed by anyone.

Testing telemetry that is not necessary for the requested test should remain optional unless Hydrion clearly explains another lawful basis.

## 6. Feedback and contribution channels

Hydrion welcomes feedback in forms that help the project act on it:

- **User story:** describe the user, need, value, and desired outcome.
- **Feature request:** describe the problem, proposed capability, expected benefit, and relevant constraints.
- **Issue or bug report:** include the build identifier, platform, device or simulator, operating system, reproduction steps, expected behaviour, actual behaviour, frequency, and non-sensitive evidence.
- **Accessibility report:** identify the assistive technology, navigation method, affected screen, and barrier.
- **Security report:** do not publish an exploitable vulnerability in a public issue. Send it through the private security contact at [SECURITY EMAIL OR PRIVATE REPORTING URL].

Official project and contribution information may be published through the Hydrion repository or The 1807 organization at https://github.com/The-1807.

Participation is not limited to testing. Skilled contributors may propose or discuss work through the project's documented contribution process. Submission does not guarantee acceptance, assignment, payment, authorship credit, or inclusion in a release.

## 7. Feedback licence

You retain ownership of original material you submit. By voluntarily providing feedback, you allow Hydrion to use, reproduce, adapt, prioritize, combine, publish, and implement the feedback for product development without payment or obligation.

This permission does not allow Hydrion to use your personal information contrary to the Privacy Policy. Source code and documentation contributions may require acceptance of repository contribution and licence terms.

## 8. Tester conduct

Testers must not:

- intentionally harm users, devices, data, infrastructure, or third-party services;
- attempt unauthorized access to accounts or data;
- publish secrets, credentials, private signing material, or exploitable security details;
- falsify results, manipulate challenges, or misrepresent test findings;
- harass contributors or other testers;
- use confidential pre-release material contrary to an applicable written testing agreement; or
- distribute a build through an unauthorized channel.

Good-faith security research must follow the published vulnerability disclosure process.

## 9. No guarantee of support or availability

Hydrion may not be able to respond to every report or maintain every test build. Reports may be closed, merged, deferred, reclassified, or declined based on reproducibility, safety, scope, value, resources, and roadmap priority.

A testing invitation does not guarantee future access, employment, payment, partnership, ownership, or a production release.

## 10. Removal from testing

Hydrion may end a test, remove access, revoke a build, or require deletion of testing materials because of security, legal, platform, operational, product, or conduct concerns.

You may leave testing at any time by uninstalling the test build, leaving the testing program, and deleting your account where applicable.

## 11. Acceptance

By installing or using a Hydrion alpha or beta build, you confirm that you understand:

- the software is unfinished and may fail;
- test data may be permanently lost;
- outputs must not be used for medical or safety-critical decisions;
- features may change or disappear; and
- your use remains subject to the Hydrion Terms of Use, Privacy Policy, and Health and Wellness Disclaimer.
