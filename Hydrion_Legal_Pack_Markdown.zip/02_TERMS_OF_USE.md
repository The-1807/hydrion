# Hydrion Terms of Use

**Effective date:** [EFFECTIVE DATE]  
**Last updated:** July 6, 2026

## 1. Agreement to these Terms

These Terms of Use are a legal agreement between you and [OPERATOR LEGAL NAME], the operator of Hydrion. They govern your access to and use of the Hydrion application, websites, accounts, local and cloud features, testing programs, support channels, content, and related services.

By downloading, accessing, creating an account, or using Hydrion, you agree to these Terms. If you do not agree, do not use Hydrion.

The Hydrion Privacy Policy explains how personal information is handled and forms part of the product relationship, but it is not intended to reduce rights provided by applicable privacy law.

## 2. Hydrion is a general wellness product

Hydrion helps users record fluid intake, set reminders and goals, review general trends, track streaks and achievements, participate in challenges, and receive general wellness prompts.

Hydrion does not provide medical advice, diagnosis, treatment, monitoring, emergency services, or a professional standard of care. It is not represented as a regulated medical device unless Hydrion expressly states otherwise for a specific version and jurisdiction.

Hydration goals, scores, estimates, reminders, achievements, and coach responses are informational and may not reflect your individual needs. Review the Health and Wellness Disclaimer before using the service.

## 3. Eligibility

You must be at least 13 years old to create an account, or older if the law where you live requires a higher minimum age. If you have not reached the age of majority, you confirm that a parent or legal guardian is aware of your use and has provided any consent required by law.

Hydrion may offer some local features without an account. Account features may be unavailable in some versions or locations.

You may not use Hydrion if applicable law prohibits you from receiving the service.

## 4. Accounts and registration

When accounts are enabled, you agree to:

- provide accurate and current registration information;
- maintain one account for your own use unless Hydrion authorizes another arrangement;
- protect your password, device, recovery method, and sign-in credentials;
- promptly update information that affects account security or service delivery;
- notify Hydrion at [SUPPORT EMAIL] if you suspect unauthorized access; and
- accept responsibility for activity performed through your account to the extent permitted by law.

Do not share authentication codes or passwords with anyone claiming to be Hydrion support. Hydrion may require verification before changing sensitive account details or processing deletion.

## 5. Licence to use Hydrion

Subject to these Terms, Hydrion grants you a limited, personal, non-exclusive, non-transferable, revocable licence to install and use the application for lawful personal use on supported devices.

This licence does not transfer ownership. Except where applicable law permits otherwise, you may not:

- copy, modify, distribute, sell, lease, sublicense, or commercially exploit Hydrion;
- reverse engineer, decompile, disassemble, or attempt to extract source code, except to the limited extent such restriction is prohibited by law or an open-source licence;
- bypass security, access controls, rate limits, or feature restrictions;
- use automated systems to scrape, overload, probe, or disrupt Hydrion;
- remove proprietary notices or misrepresent Hydrion branding; or
- use Hydrion to develop or train a competing service through unauthorized extraction of content, designs, data, or functionality.

Open-source components remain governed by their applicable licences.

## 6. Local data and device responsibility

In local-first builds, hydration logs and settings may exist only on your device. You are responsible for maintaining device access, backups, operating system updates, and available storage.

Deleting the app, clearing its storage, resetting the device, losing the device, installing an incompatible build, or participating in an alpha or beta reset may cause permanent data loss. Hydrion cannot restore information that was never transmitted to Hydrion.

Do not use Hydrion as the sole repository for information that you are legally or professionally required to preserve.

## 7. User responsibilities

You agree to:

- use Hydrion only for lawful purposes;
- enter information honestly when you expect meaningful summaries;
- apply independent judgment to reminders, goals, recommendations, and automated outputs;
- follow professional medical instructions that apply to you, including fluid restrictions;
- seek qualified medical advice for symptoms, conditions, medications, pregnancy, or concerns about hydration;
- maintain reasonable device and account security;
- respect the rights, privacy, and safety of others; and
- comply with app store and third-party integration terms.

## 8. Prohibited conduct

You must not:

- use Hydrion for an emergency, diagnosis, treatment decision, or to replace professional care;
- encourage dangerous overconsumption, deprivation, purging, disordered behaviour, self-harm, or another unsafe practice;
- upload malware, harmful code, unlawful material, or content that infringes another person's rights;
- impersonate another person or misrepresent affiliation with Hydrion;
- harass, threaten, exploit, or abuse users, contributors, testers, or maintainers;
- access another person's account or data without authorization;
- interfere with testing, security, availability, or integrity;
- falsify bug reports, manipulate challenge results, exploit rewards, or abuse promotional systems;
- use public issue channels to disclose passwords, private health information, government identifiers, or another person's personal information; or
- use Hydrion in violation of export controls, sanctions, or other applicable law.

## 9. User content, records, and feedback

You retain ownership of hydration entries, profile details, support submissions, and other original content you provide.

You grant Hydrion a limited, worldwide, royalty-free licence to host, process, reproduce, transmit, and display that content only as reasonably necessary to provide, secure, troubleshoot, and improve the service you request, comply with law, and enforce these Terms. This licence ends when the content is deleted from active systems, subject to backup rotation, legal retention, and de-identified information.

When you voluntarily submit product feedback, ideas, feature requests, user stories, or suggestions, you authorize Hydrion to use them without payment or obligation, provided Hydrion does not publicly identify you beyond the visibility you selected or otherwise use your personal information contrary to the Privacy Policy.

Public GitHub issues, discussions, and contributions are visible to others and may be governed by repository contribution terms and platform rules.

## 10. Hydrion content and intellectual property

Hydrion and its licensors own the application, source and object code, visual design, user interface, documentation, text, artwork, original characters, Hydrion name, shark logo, product marks, and other protected materials, except for user content and properly attributed third-party components.

No right to use Hydrion trademarks, logos, characters, or brand assets is granted except as necessary to use the service or under written permission.

## 11. Third-party services and integrations

Hydrion may interoperate with app stores, identity providers, Apple Health, HealthKit, Google Health Connect, wearable platforms, notification providers, GitHub, cloud hosting, payment processors, or other services.

Third-party services are independently controlled and may change, suspend, or discontinue features. Your use of them is governed by their terms and privacy policies. Hydrion is not responsible for a third party's independent acts, content, availability, or security, but Hydrion remains responsible for its own legal obligations and service provider management.

## 12. AI, local coaching, and automated outputs

Hydrion may provide local coaching prompts, rule-based summaries, predictions, or future AI-assisted outputs. These features may be experimental.

Automated outputs can be inaccurate, incomplete, delayed, generalized, or unsuitable for your circumstances. You must independently evaluate them. Do not provide unnecessary sensitive information to a free-text feature.

The current MVP does not send hydration information to an external AI provider by default. Hydrion will provide notice and choices before enabling a future external AI feature that transmits user information.

## 13. Reminders and notifications

Reminders are convenience features. Delivery may be delayed or prevented by device settings, battery restrictions, network conditions, operating system behaviour, time zone changes, app suspension, or technical failure.

Do not rely on a Hydrion reminder as a safety-critical alert, medication alarm, medical monitoring system, or emergency notification.

## 14. Alpha, beta, and experimental features

Hydrion may label a build or feature as alpha, beta, preview, experimental, or MVP. Such features may be incomplete, unstable, changed without notice, reset, or discontinued.

Testing features may produce inaccurate outputs, data loss, crashes, performance issues, or compatibility failures. Your participation is subject to the Alpha and Beta Testing Notice. Where that notice conflicts with these Terms, these Terms control unless the notice expressly states otherwise.

## 15. Changes to the service

Hydrion may add, modify, suspend, limit, or discontinue a feature to improve the product, address security or legal concerns, manage resources, or respond to platform changes.

Hydrion will use reasonable efforts to provide notice of a material change that significantly affects paid or account-based functionality, unless urgent security, legal, or operational circumstances make advance notice impractical.

The availability of a feature in one platform, country, device, or test group does not guarantee availability elsewhere.

## 16. Updates and compatibility

You may need to install updates to continue using Hydrion. An update may change functionality, data structures, device requirements, permissions, or compatibility.

Hydrion does not guarantee support for every device, operating system version, plugin, third-party service, or older build. You are responsible for confirming that your device meets published requirements.

## 17. Paid services and subscriptions

The current MVP may not include paid services. If Hydrion introduces subscriptions or paid features, the price, billing period, trial conditions, renewal method, cancellation process, included features, and refund rules will be shown before purchase.

Purchases made through an app store are also governed by the store's billing terms. Deleting the app or account may not automatically cancel a store subscription. You must cancel through the applicable subscription management process unless Hydrion states otherwise.

## 18. Suspension and termination

You may stop using Hydrion at any time. When accounts are enabled, you may request account deletion through the in-app or web process described in the Privacy Policy.

Hydrion may restrict, suspend, or terminate access when reasonably necessary because of:

- a material or repeated violation of these Terms;
- fraud, abuse, security risk, or unauthorized access;
- legal or app store requirements;
- harm to users, contributors, systems, or third parties;
- non-payment for an applicable paid service; or
- discontinuation of the service.

Where appropriate and legally permitted, Hydrion will provide notice and a reasonable opportunity to address the issue. Immediate action may be taken for urgent safety, security, legal, or abuse concerns.

Sections that by nature should survive termination remain effective, including intellectual property, disclaimers, limitations, dispute provisions, and obligations concerning prior conduct.

## 19. Service availability

Hydrion is provided over evolving software, devices, operating systems, networks, and third-party platforms. Interruptions and errors may occur.

Hydrion does not promise uninterrupted, error-free, secure, or permanent availability. This does not exclude guarantees or remedies that cannot lawfully be excluded under consumer protection law.

## 20. Disclaimer of warranties

To the maximum extent permitted by law, Hydrion is provided "as is" and "as available." Hydrion disclaims implied warranties and conditions, including merchantability, fitness for a particular purpose, accuracy, non-infringement, and uninterrupted availability.

Hydrion does not warrant that:

- a hydration estimate, score, reminder, trend, challenge, coach response, or prediction is medically appropriate;
- information entered by a user is complete or accurate;
- data will never be lost;
- all defects will be corrected;
- the service will work on every device or with every integration; or
- third-party services will remain available.

Nothing in these Terms limits rights or warranties that cannot be excluded under applicable law.

## 21. Limitation of liability

To the maximum extent permitted by law, Hydrion and its operators, contributors, licensors, and service providers will not be liable for indirect, incidental, special, consequential, exemplary, or punitive damages, or for loss of profits, opportunity, goodwill, data, or expected savings arising from or related to Hydrion.

To the maximum extent permitted by law, Hydrion's total liability for claims arising from the free service will not exceed CAD $100. For a paid service, total liability will not exceed the greater of CAD $100 or the amount you paid Hydrion for the affected service during the 12 months before the event giving rise to the claim.

These limits do not apply where prohibited by law and do not exclude liability for fraud, wilful misconduct, gross negligence where it cannot be limited, death or personal injury caused by negligence where applicable, or another liability that law does not permit Hydrion to exclude.

Some jurisdictions do not allow certain exclusions or limitations, so parts of this section may not apply to you.

## 22. Indemnity for misuse

To the extent permitted by law, you agree to reimburse Hydrion for reasonable losses, liabilities, and costs resulting from your intentional unlawful misuse of the service, infringement of another person's rights, or material violation of these Terms.

This section does not require a consumer to indemnify Hydrion for Hydrion's own negligence, legal violations, or matters that cannot lawfully be shifted to the user.

## 23. Governing law and disputes

These Terms are governed by the laws of Ontario and the federal laws of Canada applicable in Ontario, without regard to conflict-of-law principles.

Before filing a claim, you and Hydrion agree to attempt in good faith to resolve the matter by written notice to [SUPPORT EMAIL]. The notice should describe the issue and requested resolution.

Unless consumer law requires another forum, disputes that cannot be resolved informally will be brought before the courts located in Ontario, Canada. You retain any mandatory right to bring a matter before a consumer protection, privacy, small claims, or other authority in your home jurisdiction.

## 24. Changes to these Terms

Hydrion may update these Terms for product, legal, security, or operational reasons. The revision date will be updated. Hydrion will provide reasonable notice of material changes and request renewed acceptance where required.

If you do not agree to updated Terms, you must stop using the affected service and may delete your account when available.

## 25. General provisions

If a provision is found unenforceable, it will be limited or removed only to the minimum extent necessary, and the remaining provisions will remain effective.

Hydrion's failure to enforce a provision is not a waiver. You may not assign your account or rights under these Terms without written permission. Hydrion may assign these Terms as part of a legitimate reorganization, financing, merger, acquisition, or transfer of the service, subject to applicable law.

These Terms, the Privacy Policy, the Health and Wellness Disclaimer, and any feature-specific terms presented to you form the agreement concerning Hydrion.

## 26. Contact

**Operator:** [OPERATOR LEGAL NAME]  
**Support:** [SUPPORT EMAIL]  
**Privacy:** [PRIVACY EMAIL]  
**Address:** [BUSINESS OR MAILING ADDRESS]  
**Website:** [WEBSITE URL]
